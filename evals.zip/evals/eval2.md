# Goal
  "Which rocket is launching next and from where?"

Interpreting Goal...

# 🔧 Plan generated:

[
0:"launch_info_agent"
]

# 🚀 Launch Info:

{
"mission":"Project Kuiper (KA-02)"
"location":{
"name":"Space Launch Complex 41"
"city":"Cape Canaveral SFS, FL, USA"
}
"date":"2025-06-16T17:25:00Z"
}