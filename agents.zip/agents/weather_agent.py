import requests
from api_keys import WEATHERAPI_KEY

def get_weather(city):
    url = f"http://api.weatherapi.com/v1/current.json?key={WEATHERAPI_KEY}&q={city}"
    response = requests.get(url)

    if response.status_code != 200:
        raise Exception(f"❌ Failed to fetch weather data for {city}.")

    data = response.json()
    return {
        "temp": data["current"]["temp_c"],
        "conditions": data["current"]["condition"]["text"]
    }
