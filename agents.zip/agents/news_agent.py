import requests
from api_keys import NEWSAPI_KEY

def get_news(mission_name: str):
    url = "https://newsapi.org/v2/everything"
    params = {
        "q": f"{mission_name} launch",
        "sortBy": "publishedAt",
        "apiKey": NEWSAPI_KEY,
        "language": "en",
        "pageSize": 3
    }

    response = requests.get(url, params=params)

    if response.status_code != 200:
        raise Exception(f"❌ News API failed: {response.status_code} - {response.text}")

    data = response.json()
    articles = data.get("articles", [])

    if not articles:
        return "No recent news found."

    # Return formatted news headlines and URLs
    formatted = "\n\n".join(
        [f"📰 {a['title']}\n🔗 {a['url']}" for a in articles]
    )

    return formatted
