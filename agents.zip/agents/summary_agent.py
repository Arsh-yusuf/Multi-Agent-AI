def summarize(launch, weather):
    delay_risk = any(keyword in weather["conditions"].lower() for keyword in ["rain", "storm", "thunder"])
    
    return f"""
🚀 Mission: {launch['mission']}
📍 Launch Site: {launch['location']['name']} ({launch['location']['city']})
📅 Date: {launch['date']}
🌦 Weather: {weather['conditions']} at {weather['temp']}°C
{ '⚠️ Launch may be delayed due to weather.' if delay_risk else '✅ Launch weather conditions look good.' }
""".strip()
