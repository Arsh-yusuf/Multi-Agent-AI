import requests
from datetime import datetime, timezone

# Fetch the next valid upcoming launch (non-historical)
def get_next_launch():
    url = "https://ll.thespacedevs.com/2.2.0/launch/upcoming/?limit=5"
    response = requests.get(url)
    
    if response.status_code != 200:
        raise Exception("❌ Failed to fetch launch data from Launch Library 2.")
    
    launches = response.json()["results"]

    # Find the first launch in the future (in case API gives near-past ones)
    for launch in launches:
        date_str = launch["net"]
        launch_time = datetime.fromisoformat(date_str.replace("Z", "+00:00"))

        if launch_time > datetime.now(timezone.utc):
            return {
                "mission": launch["mission"]["name"] if launch["mission"] else launch["name"],
                "location": {
                    "name": launch["pad"]["name"],
                    "city": launch["pad"]["location"]["name"]
                },
                "date": launch["net"]
            }

    raise Exception("❌ No upcoming launches found.")
