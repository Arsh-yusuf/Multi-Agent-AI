def plan(user_goal: str):
    goal = user_goal.lower()
    steps = []

    if "launch" in goal:
        steps.append("launch_info_agent")

    if "weather" in goal or "forecast" in goal:
        steps.append("weather_agent")

    if "news" in goal or "articles" in goal:
        steps.append("news_agent")

    if "delay" in goal or "suitable" in goal or "summary" in goal or "conditions" in goal:
        steps.append("weather_agent")
        steps.append("summary_agent")

    return steps
